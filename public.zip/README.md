https://learn.microsoft.com/en-us/azure/static-web-apps/custom-domain-azure-dns


Debug Test:

VS Code: Terminal -> New Debug Terminal