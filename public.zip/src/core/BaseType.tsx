interface Size { width: number, height: number }

interface Position { x: number, y: number }

export type { Size, Position }
