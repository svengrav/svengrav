import { CSSProperties, Fragment, createContext, useContext, useEffect, useRef, useState } from "react"
import { Dialog, DialogPanel, DialogTitle, Transition, TransitionChild } from "@headlessui/react"
import { XMarkIcon } from "@heroicons/react/24/outline"
import classNames from "classnames"
import Icon from "./Icon"

interface ShowOverlay {
  showOverlay: (props: ShowOverlayProps) => void
}

interface ShowOverlayProps {
  label?: string
  children: any
  full?: boolean
}

interface OverlayState {
  visible: boolean
  children: any
  label?: string
  full?: boolean
}

const OverlayContext = createContext<ShowOverlay | undefined>(undefined)

// eslint-disable-next-line react-refresh/only-export-components
export const useOverlay = () => useContext(OverlayContext)

export const OverlayProvider = ({ children }: any) => {
  const [overlayState, setOverlayState] = useState<OverlayState>({
    visible: false,
    children: null,
    label: "Information",
    full: false,
  })

  const showOverlay = (props: ShowOverlayProps) => {
    setOverlayState({ visible: true, children: props.children, label: props.label, full: props.full })
  }

  return (
    <OverlayContext.Provider value={{ showOverlay }}>
      <Overlay
        {...overlayState}
        onClose={() => setOverlayState({ ...overlayState, visible: false })}
      />
      {children}
    </OverlayContext.Provider>
  )
}

interface OverlayProps {
  label?: string
  visible?: boolean
  children?: any
  onClose?: () => void
  style?: CSSProperties
  full?: boolean
}

export default function Overlay(props: OverlayProps) {
  const { children, style, label, visible = false, onClose = () => { }, full } = props
  return (
    <OverlayWrapper show={visible}>
      <div className={classNames("h-full w-full flex")}>
        {/* scrollable content */}
        <div
          className={classNames("flex flex-col h-full w-full relative z-10 m-auto p-4 justify-center items-center", {
            "max-w-3xl": !full,
            "bg-gray-950 text-white": true,
          })}
          style={style}
        >
          <div className={classNames("flex w-full font-semibold items-center text-lg mb-4 cursor-pointer justify-end", {
            "!justify-between" : label
          })}>
            {label}
            <Icon primary={XMarkIcon}  onClick={onClose}  />
          </div>
          <div className={classNames(
            "pr-2 grow overflow-y-auto",
            "scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800  w-full "
          )} >{children}</div>
        </div>
        <div className="w-full h-full bg-gray-950/50 absolute top-0 left-0 " onClick={onClose} />
      </div>
    </OverlayWrapper>
  )
}

const OverlayWrapper = ({ show, children }: { show: boolean; children: any }) => {
  return (
    <Transition appear show={show} as={Fragment}>
      <div className="w-full h-[calc(100vh_-_48px)] fixed top-12 z-50 flex">
        <TransitionChild
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          {children}
        </TransitionChild>
      </div>
    </Transition>
  )
}
