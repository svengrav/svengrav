import Page from "../../components/Page";
import { Canvas } from "../../components/Canvas";
import { CanvasWrapper } from "../../components/CanvasWrapper";
import { useWindowResize } from "../../hooks/useWindowResize";
import { SpitalMap, SpitalMapController } from "./SpitalMap";
import { useEffect, useRef, useState } from "react";
import Scalable from "../../components/Scalable";
import { Sidepanel2, Sidepanel2Controller } from "../../components/Sidepanel2";
import SpitalLogo from "./SpitalLogo";
import { SpitalArtwork, SpitalChapter, getCampChapters, getChapterById, getSpitalChapters } from "./Spital";
import { OverlayProvider, useOverlay } from "../../components/Overlay";
import classNames from "classnames";
import { ArrowsPointingOutIcon } from "@heroicons/react/24/solid";

// Set the document title
document.title = "Haus Spital - Münster";

// Define interfaces for SpitalView and SpitalState
interface SpitalViewProps {
  artwork: SpitalArtwork;
  inner?: any;
}

interface SpitalState {
  activeId: string;
  chapters: SpitalChapter[];
  view: "camp" | "event";
}

export default function SpitalView({ artwork, inner }: SpitalViewProps) {
  // Retrieve chapters for the artwork
  const spitalChapters = getSpitalChapters(artwork);
  const campChapters = getCampChapters(artwork);
  const textIntro = getChapterById(artwork, "intro");
  const textIntroExtended = getChapterById(artwork, "intro-extended");
  const textSources = getChapterById(artwork, "quellen");
  const textThanks = getChapterById(artwork, "thanks");

  // Get window size and initialize state
  const [window] = useWindowResize();
  const [spitalState, setSpitalState] = useState<SpitalState>({ activeId: "intro", chapters: campChapters, view: "camp" });

  // Use refs for the container and right panel
  const containerRef = useRef<HTMLDivElement>(null);
  const rightPanel = useRef<Sidepanel2Controller>(null);

  // Define the map controller
  const mapController: SpitalMapController = {
    moveToCamp: () => {},
    moveToPath: () => {},
    moveToPoint: () => {},
    onPointClick: (point) => {
      setSpitalState((prevState) => ({ ...prevState, activeId: point }));
      rightPanel.current?.scrollTo(point);
    },
  };

  // Set the view (camp or event)
  const setView = (view: "camp" | "event") => {
    if (view === "camp") {
      mapController.moveToCamp();
      setSpitalState((prevState) => ({ ...prevState, chapters: campChapters, view: "camp" }));
    } else {
      mapController.moveToPath();
      setSpitalState((prevState) => ({ ...prevState, chapters: spitalChapters, view: "event" }));
    }
  };

  // Set the active point
  const setActivePoint = (id: string) => {
    setSpitalState((prevState) => ({ ...prevState, activeId: id }));
    rightPanel.current?.scrollTo(id);
    
    mapController.moveToPoint(id);
  };

  // Update the artwork layer
  artwork.layer.pop();
  artwork.layer.push({
    id: "spital",
    name: "base map",
    inner: (
      <Scalable width={artwork.size.width} height={artwork.size.height}>
        <div className="w-full h-full overflow-hidden bg-spital-map-background">
          <SpitalMap controller={mapController} />
        </div>
      </Scalable>
    ),
  });

  return (
    <Page>
      <OverlayProvider>
        {/* Left side overview panel */}
        <Sidepanel2 
          position="left" 
          visible 
          closable 
          width={320}
          full={window.width < 400} 
          className="bg-spital-surface text-spital-onSurface"
          scrollbar={{className: "scrollbar-thin scrollbar-thumb-spital-onSurface scrollbar-track-spital-surface"}}
          >
          <SpitalStory
            summary={textIntro?.inner}
            details={
              <>
                <h1 className="font-semibold mt-4">{textIntroExtended?.label}</h1>
                {textIntroExtended?.inner}

                <h1 className="font-semibold mt-4">{textThanks?.label}</h1>
                {textThanks?.inner}

                <h1 className="font-semibold mt-4">{textSources?.label}</h1>
                {textSources?.inner}
              </>
            }
          />
        </Sidepanel2>
        {/* Right side panel for chapters */}
        <Sidepanel2 ref={rightPanel} position="right" closable width={350} className="bg-spital-surface text-spital-onPrimary"> 
          <div className="h-full w-full z-40 0">
            {spitalState.chapters.map((chapter) => (
              <SpitalPanel
                id={chapter.id}
                active={spitalState.activeId}
                index={chapter.index}
                label={chapter.label}
                children={chapter.inner}
                imageUri={chapter.image}
                key={chapter.id}
                onClick={(id) => setActivePoint(id)}
              />
            ))}
          </div>
        </Sidepanel2>

        {/* Main content area */}
        <div className="flex w-full h-full bg-spital-background" style={{ height: window.height - 50 }}>
          <div className="flex grow flex-col">
            <div className="grow" ref={containerRef}>
              <CanvasWrapper
                artwork={artwork}
                size={{
                  height: window.height - 120,
                  width: window.width,
                }}
              >
                <Canvas className=" " />
              </CanvasWrapper>
            </div>
            <div className="shrink">
              <SpitalMapControl onToPath={() => setView("event")} onToCamp={() => setView("camp")} />
            </div>
          </div>
        </div>
      </OverlayProvider>
    </Page>
  );
}

// Component for map control buttons
const SpitalMapControl = ({ onToCamp, onToPath }: { onToCamp: () => void; onToPath: () => void }) => {
  return (
    <div className="flex w-full justify-center py-4">
      <button onClick={onToCamp} className="bg-spital-primary hover:bg-spital-secondary rounded-md px-1 text-spital-onPrimary">
        Zum Lager
      </button>
      <button onClick={onToPath} className="bg-spital-primary hover:bg-spital-secondary rounded-md px-1 ml-2 text-spital-onPrimary">
        Zum Haus Spital
      </button>
    </div>
  );
};

// Component for individual chapter panels
const SpitalPanel = ({
  id,
  label,
  children,
  index,
  imageUri,
  active,
  onClick,
}: {
  id: string;
  label: string;
  children: any;
  index?: number;
  imageUri?: string;
  active?: string;
  onClick?: (id: string) => void;
}) => {
  const overlay = useOverlay();

  const showOverlay = () => {
    overlay?.showOverlay({ 
      full: true,
      children: 
        <div className="max-w-3xl m-auto">
          <img src={imageUri} alt="" className="mb-4" />
          {children}
        </div> 
    })
  }

  return (
    <div key={id} className="border-b border-spital-onSurface bg-spital-surface mb-4 text-spital-onSurface" id={id}>
      <div
        className={classNames("cursor-pointer text-2xl font-semibold flex mb-2 items-center", {
          "text-spital-primary": active === id,
        })}
      >
        {index && <div className="mr-2 leading-5 text-2xl rounded-full items-center justify-center text-center ">{index}</div>}
        <div onClick={() => onClick != null && onClick(id)}>{label}</div>
      </div>
      <div className="text-spital-onSurface leading-6">
        <div
          onClick={showOverlay}
          className="cursor-pointer relative group rounded-md overflow-hidden"
        >
          <div className="absolute w-full h-full hidden group-hover:flex group-hover:bg-spital-primary/80  text-spital-onPrimary justify-center items-center">
            <ArrowsPointingOutIcon className=" size-8" />
          </div>
          <img src={imageUri} alt="" />
        </div>
        <div className="my-4">{children}</div>
      </div>
    </div>
  );
};

// Component for displaying the story with a "show more" button
const SpitalStory = ({ summary, details }: { summary: any; details: any }) => {
  const overlay = useOverlay();

  const showMore = () => {
    overlay?.showOverlay({ children: details, label: "Das Projekt"});
  };

  return (
    <div className="m-4 flex flex-col">
      <div className="w-48 mb-4">
        <SpitalLogo />
        <p className="mt-4 font-semibold">Eine Münsteraner Geschichte</p>
      </div>
      {summary}
      <button onClick={() => showMore()} className="bg-spital-primary hover:bg-spital-secondary text-spital-onPrimary rounded-md p-1 mt-4">
        Mehr erfahren
      </button>
    </div>
  );
};
