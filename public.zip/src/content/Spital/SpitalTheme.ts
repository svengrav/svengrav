
export const spitalTheme = {
  colors: {
    spital: {
      primary: '#D3D9D4', 
      onPrimary: '#576d71',
      secondary: '#afb6a9',
      secondaryVariant: '',
      onSecondary: '',
      background: '#2E3944',
      onBackground: '',
      label: '#ffffff',
      content: '#ffffff',
      surface: '#212A31',
      onSurface: '#93a8ac',

      map: {
        background: '#2E3944',
        label: '#e9e9e9',
        building: "#232d36",
        forest: "#90AEAD",
        forestBorder: "#6a9383",
        cross: "#E64833",
        cemetery: "#E64833",
        streets: "#666",
        camp: {
          base: "#ffffff",
          wire: "#ffffff",
          spots: "#a5a6a0",
        },
        eventPath: "#E64833",
      },
    
    },
  },
};

// export const spitalTheme = {
//   colors: {
//     spital: {
//       primary: '#E64833', 
//       onPrimary: '#ffffff',
//       secondary: '#c52828',
//       secondaryVariant: '',
//       onSecondary: '',
//       background: '#244855',
//       onBackground: '',
//       label: '#ffffff',
//       content: '#ffffff',
//       surface: '#244855',
//       onSurface: '#90AEAD',

//       map: {
//         background: '#244855',
//         label: '#e9e9e9',
//         building: "#193742",
//         forest: "#90AEAD",
//         forestBorder: "#6a9383",
//         cross: "#E64833",
//         cemetery: "#E64833",
//         streets: "#666",
//         camp: {
//           base: "#E64833",
//           wire: "#E64833",
//           spots: "#365865",
//         },
//         eventPath: "#E64833",
//       },
    
//     },
//   },
// };

export default spitalTheme;
