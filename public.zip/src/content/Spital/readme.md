#  2024 | 2014 | 1914 - Eine Münsteraner Geschichte

## ToDo
- Wenn in der Lageransicht ein Chapter in der Sidebar angeklickt wird, soll das Element auf der Karte markiert werden.
- Die Labels des Lagers müssen noch richtig positioniert werden.
- LinkedIn Icon im Header mit Close Button der Sidebar synchen
- Event oder Path als ID