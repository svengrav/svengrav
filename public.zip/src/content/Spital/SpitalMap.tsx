import { useState, useRef, useEffect, CSSProperties, ReactNode } from "react";
import classNames from "classnames";
import { getSpitalMapSVG as newSpitalMapSVG } from "./SpitalMapSVG";
import { campLabel, MapElement, mapViews, Position, spitalLabel, spitalEventPoints, mapTitle, getMapTitle, spitalMapData } from "./SpitalMapData";
import { SpitalMapCamp } from "./SpitalCampMap";
import spitalTheme from "./SpitalTheme";

export interface SpitalMapController {
  moveToCamp: () => void;
  moveToPath: () => void;
  moveToPoint: (id: string) => void;
  onPointClick?: (id: string) => void;
}

interface MapState {
  initialized: boolean;
  activePoint?: string;
  elements: Array<MapElement & any>;
}

const positionToTransformValue = ({ x, y, s }: Position) => `translate(${x}px, ${y}px) scale(${s})`;

const getMapElement = (id: string, elements: MapElement[]) => elements.find((p) => p.id === id)!;

const camp = getMapElement("camp", mapViews);
const path = getMapElement("path", mapViews);

export const SpitalMap = ({ controller }: { controller: SpitalMapController }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const initTransform = positionToTransformValue(camp.position as Position);
  const [mapState, setMapState] = useState<MapState>({ initialized: false, elements: [] });
  const colors = spitalTheme.colors.spital.map;

  useEffect(() => {
    if (!mapState.initialized) {
      newSpitalMapSVG(spitalMapData.id).then((svg) => {
        mapContainerRef.current?.querySelector(`#${spitalMapData.id}`)?.remove();
        mapContainerRef.current?.appendChild(svg);

        campLabel.forEach((key) => {
          key.connections?.forEach((connection) => {
            const element = createMapConnection(mapContainerRef.current!, spitalMapData.id, key.id, connection);
            mapState.elements.push(element);
          });
        });

        setMapState((prevState) => ({ ...prevState, initialized: true }));
      });
    }
  }, [mapState.initialized]);

  //#region map controller methods
  controller.moveToCamp = () => {
    moveToPosition(camp.position as Position);
  };

  controller.moveToPath = () => {
    moveToPosition(path.position as Position);
  };

  controller.moveToPoint = (id: string) => {
    setMapState((prevState) => ({ ...prevState, activePoint: id }));
    const pointElement = mapContainerRef.current?.querySelector(`#${id}`);
    pointElement?.scrollIntoView({ behavior: "smooth", block: "center" });
    mapState.elements.forEach((element) => element.hide());
    mapState.elements.find((element) => element.sourceId === id)?.show();
  };
  //#endregion

  // Moves the map to a specific position.
  const moveToPosition = (position: Position) => {
    const { x, y, s } = position;
    mapContainerRef.current?.animate([{ transform: `translate(${x}px, ${y}px) scale(${s})` }], {
      duration: 1000,
      fill: "forwards",
    });
  };

  // Handles the click event on a map point.
  const onMapClick = (id: string) => {
    mapState.elements.forEach((element) => element.hide());
    mapState.elements.find((element) => element.sourceId === id)?.show();
    controller.onPointClick && controller.onPointClick(id);
    setMapState((prevState) => ({ ...prevState, activePoint: id }));
  };

  return (
    <div
      className="text-spital-map-label relative"
      style={{
        transform: initTransform,
        transformOrigin: "top left",
        opacity: mapState.initialized ? 1 : 0,
        visibility: mapState.initialized ? "visible" : "hidden",
        transition: "opacity 0.5s, visibility 0.3s",
        width: 1250,
        height: 1000,
        background: colors.background,
      }}
      ref={mapContainerRef}
    >
      <SpitalMapCamp
        className="absolute z-20 "
        style={{ top: 476, left: 1007, transform: "scale(0.471) rotate(53.11deg) ", transformOrigin: "top left" }}
      />

      <div className="absolute z-10">
        <MapTitle id={getMapTitle("path")?.id} position={getMapTitle("path")?.position} title={getMapTitle("path").inner}  style={{fontSize: 20}} />
        <MapTitle id={getMapTitle("camp")?.id} position={getMapTitle("camp")?.position} title={getMapTitle("camp").inner} />

        {campLabel.map(({ id, position, label }) => (
          <MapLabel
            key={id}
            id={id}
            label={label!}
            position={position as Position}
            onClick={onMapClick}
            style={{
              paddingRight: 2, 
              fontSize: 10,
            }}
            activeId={mapState.activePoint}
          />
        ))}

        {spitalLabel.map(({ id, position, label }) => (
          <MapLabel
            key={id}
            id={id}
            label={label!}
            position={position as Position}
            activeId={mapState.activePoint}
            style={{ fontSize: 10 }}
          />
        ))}

        {spitalEventPoints.map(({ id, position, label }) => (
          <MapPoint
            key={id}
            id={id}
            label={label}
            position={position as Position}
            onClick={onMapClick}
            active={mapState.activePoint}
            
          />
        ))}
      </div>
    </div>
  );
};

/**
 * Props for the MapTitle component.
 */
interface MapTitleProps {
  id: string;
  position: Position;
  title: ReactNode;
  style?: CSSProperties;
}

/**
 * A component representing a title on the map.
 * @param {MapTitleProps} props - The properties for the MapTitle component.
 * @returns {JSX.Element} The rendered MapTitle component.
 */
export const MapTitle =  ({ id, position, title, style } : MapTitleProps) => {
  return (
    <div
      id={id}
      className={classNames(
        'font-semibold absolute uppercase tracking-wider whitespace-nowrap'
      )}
      style={{
        top: position.y,
        left: position.x,
        ...style
      }}
    >
      {title}
    </div>
  );
};


/**
 * Props for the MapLabel component.
 */
interface MapLabelProps {
  id: string;
  position: Position;
  label?: string;
  activeId?: string;
  onClick?: (id: string) => void;
  style?: CSSProperties;
}

/**
 * A component representing a label on the map.
 * @param {MapLabelProps} props - The properties for the MapLabel component.
 * @returns {JSX.Element} The rendered MapLabel component.
 */
export const MapLabel = ({ id, label, position, onClick, style }: MapLabelProps) => {
  const handleClick = () => {
    if (onClick) {
      onClick(id);
    }
  };

  return (
    <div
      id={id}
      onClick={handleClick}
      className={classNames(
        'absolute flex justify-center items-center cursor-pointer whitespace-nowrap font-semibold text-center'
      )}
      style={{
        left: position.x,
        top: position.y,
        transformOrigin: 'center',
        transform: `rotate(${position.r ?? 0}deg)`,
        ...style,
      }}
    >
      <div className={classNames({ 'hover:bg-spital-primary hover:text-spital-onPrimary rounded-sm p-0.5': !!onClick })}>
        {label}
      </div>
    </div>
  );
};

interface MapPointProps {
  id: string;
  position: Position;
  onClick?: (id: string) => void;
  label?: string;
  active?: string;
  style?: CSSProperties;
  className?: string;
}

const MapPoint = ({ id, label, active, className, position, style, onClick }: MapPointProps) => {
  const handleClick = () => {
    if (onClick) {
      onClick(id);
    }
  };

  return (
    <div
      id={id}
      onClick={handleClick}
      className={classNames(
        "rounded-md absolute w-5 h-5 text-center flex justify-center items-center cursor-pointer",
        "bg-spital-secondary hover:bg-spital-primary text-spital-onSecondary",
        {
          "bg-spital-primary, text-spital-onPrimary": active === id,
        },
        className
      )}
      style={{ 
        left: position.x, 
        top: position.y, 
        transform: `rotate(${position.r ?? 0}deg)`,
        ...style
      }}>
      {label}
    </div>
  );
};

/**
 * Creates a connection between a source element and a target point on the map.
 * @param container - The container element that holds the map and source element.
 * @param mapId - The ID of the SVG element within the container where the connection path will be appended.
 * @param sourceId - The ID of the source element within the container.
 * @param target - The target position as an object with x and y coordinates.
 * @param style - Optional CSS properties to style the connection path.
 * @returns An object containing the connection details and methods to toggle, show, or hide the connection.
 */
const createMapConnection = (container: HTMLDivElement, mapId: string, sourceId: string, target: Position, style?: CSSProperties) => {
  const sourceElement = container.querySelector<HTMLDivElement>(`#${sourceId}`);
  if (!sourceElement) {
    console.error(`Source element with ID ${sourceId} not found`);
    return null;
  }

  const source = {
    x: sourceElement.offsetLeft + sourceElement.offsetWidth,
    y: sourceElement.offsetTop,
  };

  const connectionPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
  connectionPath.id = `${sourceId}-to-${target.x}-${target.y}`;
  const pathData = `M ${source.x},${source.y} L ${target.x},${target.y}`;
  connectionPath.setAttribute("d", pathData);

  Object.assign(connectionPath.style, {
    transition: "opacity 0.5s, visibility 0.3s",
    stroke: "white",
    strokeWidth: "0.5",
    opacity: "0",
    zIndex: "50",
    ...style,
  });

  const svgContainer = container.querySelector<SVGElement>(`#${mapId}`);
  if (!svgContainer) {
    console.error(`SVG container with ID ${mapId} not found`);
    return null;
  }

  svgContainer.appendChild(connectionPath);

  const toggleVisibility = () => {
    const element = container.querySelector<SVGPathElement>(`#${connectionPath.id}`);
    if (element) {
      element.style.opacity = element.style.opacity === "0" ? "1" : "0";
    }
  };

  const show = () => {
    const element = container.querySelector<SVGPathElement>(`#${connectionPath.id}`);
    if (element) {
      element.style.opacity = "1";
    }
  };

  const hide = () => {
    const element = container.querySelector<SVGPathElement>(`#${connectionPath.id}`);
    if (element) {
      element.style.opacity = "0";
    }
  };

  return {
    id: connectionPath.id,
    sourceId,
    start: source,
    end: target,
    toggleVisibility,
    show,
    hide,
  };
};
